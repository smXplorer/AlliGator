# FLI_Dataset_Plugin_Example.py
# Example AlliGator FLI Dataset Menu Python Plugin
# Tested with AlliGator version 1.09
# Author: X. Michalet
# Last modified: 2026-10-21

# The following (triple) comment is needed to specify the AlliGator Python 
# Plugin API version number to use

### AlliGator Python Plugin API Version = 1.1.1 ###

# The following (triple) comment is needed to tell AlliGator where to
# insert the plugin function(s) as menu item(s)
# the syntax after the AlliGatorTarget = keyword is:
# Window/Type_of_Destination/Destination
# where 'Window' is the target AlliGator window, 'Type_of_Destination' is
# 'Object' or 'Menu', and 'Destination' is the name of the object,
# or the menu item under which to insert the script's functions as
# 'script_name>>plugin function'

### AlliGatorTarget = AlliGator/Menu/FLI Dataset ###

# The following modules are needed to interpret incoming data and send outputs

import json

import os
os.environ["ALLIGATOR_DEFINITIONS_VERSION"] = "1.1.1"
import alligator_def

# the following module is used in this plugin

import numpy as np

def Peak_Intensity_Above_Threshold_Mask(
        plugin_data_in, params_in_json, addtl_params_out_json_list):
        
    """Peak Intensity Above Threshold Mask

    Expects one float parameter (th: float64)
    from the calling VI and processes the incoming Dataset as follows:
    max of all gates -> max
    if max > th, mask = 1, else mask = 0
    identifying pixels for which the peak intensity is larger than the threshold
    The resulting processed mask image is returned to AlliGator
    """
    # The following (triple) comment indicates that this function is a plugin
    # This is to distinguish it from accessory functions that should
    # not be imported in AlliGator's menus

    ### IsAlliGatorPythonPlugin ###

    # The following (triple commented) section describes which
    # additional parameters are required for that function.
    # If no parameter is needed this section can be ignored

    ### AlliGator Input Parameters Definitions ###
    ### th:float64            # peak intensity threshold parameter
    ### End of AlliGator Input Parameters Definitions ###

    # The following (triple commented) section is mandatory to know which
    # type of output this function returns and which AlliGator
    # object they are destined to

    ### AlliGator Output Value Type & Destination ###
    ### Mask Image:Source Image # sends Mask Image to Source Image display

    ### End of AlliGator Output Value Type & Destination ###

    # get and decode the dataset
    
    fli_dataset_data = plugin_data_in.FLI_Dataset_Plugin_Data
    fli_dataset_name = fli_dataset_data.FLI_Dataset_Name
    gate_duration = fli_dataset_data.Gate_Duration
    gate_separation = fli_dataset_data.Gate_Separation
    gate_number = fli_dataset_data.Gate_Number
    size_x = fli_dataset_data.X_Size
    size_y = fli_dataset_data.Y_Size
    images = fli_dataset_data.Image_Data_List

    # decode the parameter string

    params = json.loads(params_in_json)
    threshold = params['th']
    
    # process gate series
    
    max = np.zeros((size_y,size_x),dtype=np.float32)    # init max image
    for i in range(gate_number):
        gate = np.asarray(images[i].Image)
        max = np.maximum(max, gate, out = max)
    mask = (max > threshold).astype('uint16')  # set values > th in max to 1
                                               # set values <= th to 0
    mask_as_list = mask.tolist() # LabVIEW only accepts list as array output

    # packages the data into a Python Plugin data structure
    # First builds a FLI Dataset data structure
    
    fli_dataset_data_out = alligator_def.fli_dataset_plugin_data(
        FLI_Dataset_Name = '',
        Gate_Duration = 0,
        Gate_Separation = 0,
        Gate_Number = 1,
        X_Size = size_x,
        Y_Size = size_y,
        Image_Data_List = [],
        Mask_Image = mask_as_list,
        Sum_Image = [],
        Max_Image = [],
        Min_Image = [])

    # Then builds a Python Plugin data structure containing the FLI Dataset 
    # data structure
    
    plugin_data_out = alligator_def.plugin_data(
        Image_Plugin_Data = alligator_def.empty_image,
        Graph_Plugin_Data = alligator_def.empty_graph,
        Parameter_Map_Plugin_Data = alligator_def.empty_parameter_map,
        FLI_Dataset_Plugin_Data = fli_dataset_data_out)
    
    # We can send back information on the function outcome
    # and can also set AlliGator Parameters
    # all this packaged in a dictionary, converted to json and
    # appended to the (generally) empty string list
    # addtl_params_out_json_list
    # Note: space and case are irrelevant in the item names

    info_out_dict = {
    "Notebook Message" : "Mask image from peak intensity above threshold",
    "Exception Type" : "None", # could also be "Warning" or "Error"
    "Exception Message" : "", # provide verbose information for error
    }
    
    # conversion to JSON string and string is appended to the incoming
    # addtl_params_out_json_list (which is empty in this example)
    # Note that AlliGator will ignore everything but the last string in the list
    
    addtl_params_out_json_list.append(json.dumps(info_out_dict))
    
    # return the plugin data to AlliGator
    
    return(plugin_data_out)